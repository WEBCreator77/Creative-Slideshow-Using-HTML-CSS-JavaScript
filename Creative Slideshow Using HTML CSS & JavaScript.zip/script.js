const slider = document.querySelector(".slider").children;
const sliderEffectContainer = document.querySelector(".effect-box");
const slideTime = 3000;
const slideTimeOut = 2000;
const sliderHeight = slider[0].offsetHeight;
const sliderWidth = slider[0].offsetWidth;
const row = 15;
const col = 15;
let index = 0;

function createEffectBox() {
       for (let i = 0; i < row; i++) {
              for (let j = 0; j < col; j++) {
                     const box = document.createElement("div");
                     box.className = "box";
                     box.style.width = (sliderWidth / row) + "px";
                     box.style.height = (sliderHeight / col) + "px";
                     sliderEffectContainer.appendChild(box);
                     hideEffectBox();
              }
       }
}

function slideShow() {
       hideEffectBox();
       for (let i = 0; i < slider.length; i++) {
              slider[i].classList.remove("active", "slider-out");
       }
       slider[index].classList.add("active");
       if (index === slider.length - 1) {
              index = 0;
       } else {
              index++;
       }

       setTimeout(() => {
              showEffectBox();
              slider[index].classList.add("slider-out");
       }, slideTimeOut);

       setTimeout(() => {
              if (index === slider.length - 1) {
                     index = 0;
              } else {
                     index++;
              }
              slideShow();
       }, slideTime);
}

function hideEffectBox() {
       for (let i = 0; i < sliderEffectContainer.children.length; i++) {
              sliderEffectContainer.children[i].classList.remove("show");
              sliderEffectContainer.children[i].classList.add("hide");
       }
}

function showEffectBox() {
       for (let i = 0; i < sliderEffectContainer.children.length; i++) {
              sliderEffectContainer.children[i].classList.remove("hide");
              sliderEffectContainer.children[i].classList.add("show");
       }
}

window.onload = () => {
       createEffectBox();
       slideShow();
}






















